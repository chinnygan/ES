#!/usr/bin/bash
source /group/teaching/espractical/OpenOCD/setup.sh
/group/teaching/espractical/OpenOCD/flash.sh main