#!/usr/bin/bash
alias src="source /group/teaching/espractical/OpenOCD/setup.sh"
alias flash="/group/teaching/espractical/OpenOCD/flash.sh main"