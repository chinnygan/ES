#!/usr/bin/bash
alias src="source /group/teaching/espractical/OpenOCD/setup.sh"
alias flash="/group/teaching/espractical/Part2/Scripts/flash.sh main"