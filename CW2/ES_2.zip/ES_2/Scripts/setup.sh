export PATH=$PATH:/group/teaching/espractical/Freescale/ARM_Tools/Command_Line_Tools
export LM_LICENSE_FILE=27900@arcsimvm1.inf.ed.ac.uk
