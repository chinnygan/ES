#!/bin/sh

screen /dev/ttyACM0 115200
